Notepad2-mod x86-64 简体中文化计划

Notepad2-mod 虽然有很多人在使用，并且也有人做出了很不错的翻译，但是一直都只局限于32位版本，由此，本人开始将64位版的Notepad2-mod 也进行了简体中文化。

2012/1/9
Notepad2-mod 4.2.25 rev689 x86-64 简体中文版首次发布，很可能有不少没有发现的错误和翻译不妥，请指正。
2012/1/17
Notepad2-mod 4.2.25 rev698 x86-64 简体中文版发布
2012/1/23
Notepad2-mod 4.2.25 rev705 x86-64 简体中文版发布
2012/3/4
Notepad2-mod 4.2.25 rev720 x86-64 简体中文版发布
2012/5/5
Notepad2-mod 4.2.25 rev735 x86-64 简体中文版发布
2012/7/18
Notepad2-mod 4.2.25 rev753 x86-64 简体中文版发布
2012/8/27
Notepad2-mod 4.2.25 rev760 x86-64 简体中文版发布
2012/9/6
Notepad2-mod 4.2.25 rev774 x86-64 简体中文版发布
2012/9/26
Notepad2-mod 4.2.25 rev796 x86-64 简体中文版发布
2013/1/26
Notepad2-mod 4.2.25 rev823 x86-64 简体中文版发布
2013/3/21
Notepad2-mod 4.2.25 rev837 x86-64 简体中文版发布
2013/4/9
Notepad2-mod 4.2.25 rev844 x86-64 简体中文版发布
2013/5/17
Notepad2-mod 4.2.25 rev855 x86-64 简体中文版发布
2013/5/22
Notepad2-mod 4.2.25 rev856 x86-64 简体中文版发布
2013/7/23
Notepad2-mod 4.2.25 rev870 x86-64 简体中文版发布
2013/12/15
Notepad2-mod 4.2.25 rev890 x86-64 简体中文版发布
2013/12/17
Notepad2-mod 4.2.25 rev891 x86-64 简体中文版发布
2014/1/3
Notepad2-mod 4.2.25 rev897 x86-64 简体中文版发布
2014/3/24
Notepad2-mod 4.2.25 rev904 x86-64 简体中文版发布
2014/4/21
Notepad2-mod 4.2.25 rev906 x86-64 简体中文版发布
2014/10/3
Notepad2-mod 4.2.25 rev935 x86-64 简体中文版发布
2014/12/4
Notepad2-mod 4.2.25 rev939 x86-64 简体中文版发布
2015/2/23
Notepad2-mod 4.2.25 rev940 x86-64 简体中文版发布
2015/3/11
Notepad2-mod 4.2.25 rev945 x86-64 简体中文版发布
2015/4/19
Notepad2-mod 4.2.25 rev953 x86-64 简体中文版发布
2015/5/27
Notepad2-mod 4.2.25 rev954 x86-64 简体中文版发布
2015/6/23
Notepad2-mod 4.2.25 rev955 x86-64 简体中文版发布
2015/9/15
Notepad2-mod 4.2.25 rev964 x86-64 简体中文版发布
2016/1/29
Notepad2-mod 4.2.25 rev970 x86-64 简体中文版发布
2016/3/29
Notepad2-mod 4.2.25 rev972 x86-64 简体中文版发布
2016/6/6
Notepad2-mod 4.2.25 rev980 x86-64 简体中文版发布

Semidio
Semidio7@gmail.com

附录：通过映像劫持实现Notepad2替换记事本
1、打开注册表创建如下注册表项：HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\notepad.exe，如果无法修改，需要先右键取得权限；
2、在notepad.exe注册表项中，创建名为Debugger的字符串值(REG_SZ)；
3、修改字符串值Debugger的数据为Notepad2.exe的完整路径，最后以 /z参数结尾。(如："D:\Program Files\Notepad2\Notepad2.exe" /z)